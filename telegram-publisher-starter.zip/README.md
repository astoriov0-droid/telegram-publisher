# Telegram Publisher

A lightweight scheduled publisher controlled by Telegram commands.

## Setup
1. Add repository secret `TELEGRAM_BOT_TOKEN` with a newly rotated BotFather token.
2. In Settings → Actions → General, allow GitHub Actions to read and write repository contents.
3. Ensure the workflow has `contents: write` permission.
4. Add the bot as an admin in each channel where it should post, or ensure it can send messages in a group.
5. Enable Actions and run the workflow once using Actions → Telegram Publisher → Run workflow.
6. Open a private chat with your bot and send `/start`.

## Commands
- `/setmessage your text`
- `/addchat CHAT_ID`
- `/removechat CHAT_ID`
- `/interval 60` (minutes; minimum 5)
- `/startposting`
- `/stop`
- `/status`

The workflow checks every five minutes. GitHub scheduled runs can be delayed and are not an exact timer. Use only destinations where you have permission to post. Avoid repetitive unsolicited messages.
