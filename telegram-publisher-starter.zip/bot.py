import os, json, time, base64, requests
from datetime import datetime, timezone

TOKEN = os.environ["9261781736:AAE8aJ1zQ1EBhpAKvQxPiAJENzm2Ob3ZyyM"]
ADMIN_ID = 7036958261
REPO = os.environ["GITHUB_REPOSITORY"]
GH_TOKEN = os.environ["GITHUB_TOKEN"]
API = f"https://api.telegram.org/bot{TOKEN}"
GH_API = f"https://api.github.com/repos/{REPO}/contents/config.json"
HEADERS = {"Authorization": f"Bearer {GH_TOKEN}", "Accept": "application/vnd.github+json"}

DEFAULT = {"offset": 0, "enabled": False, "message": "", "interval": 3600,
           "last_sent": 0, "targets": []}

def load_state():
    r = requests.get(GH_API, headers=HEADERS)
    if r.status_code == 404:
        return DEFAULT.copy(), None
    r.raise_for_status()
    data = r.json()
    state = json.loads(base64.b64decode(data["content"]).decode())
    return state, data["sha"]

def save_state(state, sha):
    content = base64.b64encode(json.dumps(state, ensure_ascii=False, indent=2).encode()).decode()
    payload = {"message": "Update publisher settings", "content": content}
    if sha:
        payload["sha"] = sha
    r = requests.put(GH_API, headers=HEADERS, json=payload)
    r.raise_for_status()
    return r.json()["content"]["sha"]

def tg(method, payload=None):
    r = requests.post(f"{API}/{method}", json=payload or {}, timeout=25)
    r.raise_for_status()
    result = r.json()
    if not result.get("ok"):
        raise RuntimeError(result)
    return result.get("result")

def send(chat_id, text):
    tg("sendMessage", {"chat_id": chat_id, "text": text, "disable_web_page_preview": True})

def main():
    state, sha = load_state()
    updates = tg("getUpdates", {"offset": state["offset"], "timeout": 0, "allowed_updates": ["message"]})
    changed = False
    for u in updates:
        state["offset"] = max(state["offset"], u["update_id"] + 1)
        m = u.get("message", {})
        chat = m.get("chat", {})
        user = m.get("from", {})
        if user.get("id") != ADMIN_ID or chat.get("type") != "private":
            continue
        txt = (m.get("text") or "").strip()
        cid = str(chat["id"])
        if txt == "/start":
            send(cid, "أهلًا! أوامر التحكم:\n/status - الحالة\n/setmessage نص الرسالة\n/addchat ID - إضافة وجهة مسموح بها\n/removechat ID - حذف وجهة\n/interval دقائق - تحديد الفاصل (5 دقائق فأكثر)\n/startposting - تشغيل\n/stop - إيقاف")
        elif txt == "/status":
            send(cid, f"النشر: {'يعمل' if state['enabled'] else 'متوقف'}\nالفاصل: {state['interval']//60} دقيقة\nالوجهات: {len(state['targets'])}\nالرسالة: {state['message'][:300] or 'غير محددة'}")
        elif txt.startswith("/setmessage "):
            state["message"] = txt.split(" ", 1)[1]
            send(cid, "تم حفظ الرسالة.")
            changed = True
        elif txt.startswith("/addchat "):
            target = txt.split(" ", 1)[1].strip()
            if target not in state["targets"]:
                state["targets"].append(target)
            send(cid, "تمت إضافة الوجهة. تأكد أن البوت لديه إذن النشر فيها.")
            changed = True
        elif txt.startswith("/removechat "):
            target = txt.split(" ", 1)[1].strip()
            state["targets"] = [x for x in state["targets"] if x != target]
            send(cid, "تم حذف الوجهة.")
            changed = True
        elif txt.startswith("/interval "):
            try:
                mins = int(txt.split()[1])
                if mins < 5: raise ValueError()
                state["interval"] = mins * 60
                send(cid, "تم ضبط الفاصل.")
                changed = True
            except Exception:
                send(cid, "اكتب /interval 60 (5 دقائق على الأقل).")
        elif txt == "/startposting":
            if not state["message"] or not state["targets"]:
                send(cid, "أضف رسالة ووجهة أولًا.")
            else:
                state["enabled"] = True
                send(cid, "تم تشغيل الجدولة.")
                changed = True
        elif txt == "/stop":
            state["enabled"] = False
            send(cid, "تم إيقاف الجدولة.")
            changed = True
    now = time.time()
    if state["enabled"] and state["message"] and state["targets"] and now - state["last_sent"] >= state["interval"]:
        for target in list(state["targets"]):
            try:
                send(target, state["message"])
            except Exception as e:
                print(f"Send failed for {target}: {e}")
        state["last_sent"] = now
        changed = True
    if changed or updates:
        save_state(state, sha)

if __name__ == "__main__":
    main()
